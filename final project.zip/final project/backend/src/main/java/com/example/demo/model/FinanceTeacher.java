package com.example.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "financeTeacher")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class FinanceTeacher {
    
    private Integer _id;
    private String firstname;
    private String lastname;
    private String month;
    private Number money;

    private Teacher teacher;

    public FinanceTeacher() {
    }

    //one to one(teacher and financeTeacher)
    @OneToOne(mappedBy = "financeTeacher", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public FinanceTeacher(Integer _id, String firstname, String lastname, String month, Number money) {
        this._id = _id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.month = month;
        this.money = money;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Number getMoney() {
        return money;
    }

    public void setMoney(Number money) {
        this.money = money;
    }


    
    

}
