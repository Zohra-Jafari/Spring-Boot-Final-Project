package com.example.demo;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner{

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		User initialUser = userRepository.findByUsername("admin");

		if(initialUser == null){
			User user1 = new User(1,"Zohra", "jafari", "admin@gmail.com", "admin", bCryptPasswordEncoder.encode("admin"));
			userRepository.save(user1);

		User user2 = new User(2,"tayaba","tay", "tayaba@gmail.com","admin1", bCryptPasswordEncoder.encode("admin1"));
		userRepository.save(user2);

		}

		
	}

}
