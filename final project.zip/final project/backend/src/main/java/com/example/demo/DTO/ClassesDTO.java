package com.example.demo.DTO;

import java.util.Set;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class ClassesDTO {
    
    private Integer _id;
	private String classname;

    private Set<Integer> students_Ids;
    private Integer teacher_Id;


    public ClassesDTO() {
    }


    public Integer getTeacher_Id() {
        return teacher_Id;
    }


    public void setTeacher_Id(Integer teacher_Id) {
        this.teacher_Id = teacher_Id;
    }


    public Set<Integer> getStudents_Ids() {
        return students_Ids;
    }


    public void setStudents_Ids(Set<Integer> students_Ids) {
        this.students_Ids = students_Ids;
    }


    public ClassesDTO(Integer _id, String classname) {
        this._id = _id;
        this.classname = classname;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }


    public void set_id(Integer _id) {
        this._id = _id;
    }


    public String getClassname() {
        return classname;
    }


    public void setClassname(String classname) {
        this.classname = classname;
    }





    

}
