package com.example.demo.model;

import javax.persistence.CascadeType;

// import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
// import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "financeStudent")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class FinanceStudent {

    private Integer _id;
    private String firstname;
    private Number idnumber;
    private String month;
    private Number money;


	private Student student;


	

    //default constractor
    public FinanceStudent() {
    }

	//one to many(finanaceS and student)	
	@OneToOne(mappedBy = "FStudent", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	//overload constractor
    public FinanceStudent(Integer _id, String firstname,Number idnumber, String month, Number money) {
        this._id = _id;
        this.firstname = firstname;
        this.idnumber = idnumber;
        this.month = month;
        this.money = money;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer get_id() {
		return _id;
	}


	public void set_id(Integer _id) {
		this._id = _id;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public Number getIdnumber() {
		return idnumber;
	}


	public void setIdnumber(Number idnumber) {
		this.idnumber = idnumber;
	}


	public String getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month = month;
	}


	public Number getMoney() {
		return money;
	}


	public void setMoney(Number money) {
		this.money = money;
	}



    
    
}
