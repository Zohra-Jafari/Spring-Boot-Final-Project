package com.example.demo.services;

import java.util.List;

import com.example.demo.DTO.ClassesDTO;
import com.example.demo.model.Classes;








public interface ClassServices {
    
    Classes addClass(Classes classe);

	List<Classes> getAllClasses();

	Classes getClassById(Integer id);

	void deleteClassById(Integer id);

    List<ClassesDTO> convertToDTO(List<Classes> classes);

    ClassesDTO convertToDTO(Classes classes);

	
}
