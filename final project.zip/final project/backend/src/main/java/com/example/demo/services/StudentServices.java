package com.example.demo.services;

import java.util.List;

import com.example.demo.DTO.StudentDTO;
import com.example.demo.model.Student;



public interface StudentServices {
    
    Student addStudent(Student student);

	List<Student> getAllStudents();

	Student getStudentById(Integer id);

	void deleteStudentById(Integer id);

	List<StudentDTO> convertToDTO(List<Student> students);
	StudentDTO convertToDTO(Student student);
	
}
