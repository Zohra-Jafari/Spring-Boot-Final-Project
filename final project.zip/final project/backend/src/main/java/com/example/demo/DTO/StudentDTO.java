package com.example.demo.DTO;

import java.util.Set;



public class StudentDTO {
    
    private Integer _id;
    private String firstname;
    private String lastname;
    private String fathername;
    private String gender;
    private Number idnumber;
    private String classname;
    private String time;
    private Number year;

    private Integer classSc_Id;
    private Integer FStudent_Id;
    private Set<Integer> teachers_Ids;


    
    public Integer get_id() {
        return _id;
    }
    
    public Set<Integer> getTeachers_Ids() {
        return teachers_Ids;
    }

    public void setTeachers_Ids(Set<Integer> teachers_Ids) {
        this.teachers_Ids = teachers_Ids;
    }

    public Integer getFStudent_Id() {
        return FStudent_Id;
    }

    public void setFStudent_Id(Integer fStudent_Id) {
        this.FStudent_Id = fStudent_Id;
    }

    public Integer getClassSc_Id() {
        return classSc_Id;
    }

    public void setClassSc_Id(Integer classSc_Id) {
        this.classSc_Id = classSc_Id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getFathername() {
        return fathername;
    }
    public void setFathername(String fathername) {
        this.fathername = fathername;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public Number getIdnumber() {
        return idnumber;
    }
    public void setIdnumber(Number idnumber) {
        this.idnumber = idnumber;
    }
    public String getClassname() {
        return classname;
    }
    public void setClassname(String classname) {
        this.classname = classname;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public Number getYear() {
        return year;
    }
    public void setYear(Number year) {
        this.year = year;
    }



    

    
}
