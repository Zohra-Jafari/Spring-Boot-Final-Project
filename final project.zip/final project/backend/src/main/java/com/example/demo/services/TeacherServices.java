package com.example.demo.services;

import java.util.List;

import com.example.demo.DTO.TeacherDTO;
import com.example.demo.model.Teacher;







public interface TeacherServices {
    
    Teacher addTeacher(Teacher teacher);

	List<Teacher> getAllTeachers();

	Teacher getTeacherById(Integer id);

	void deleteTeacherById(Integer id);

    List<TeacherDTO> convertToDTO(List<Teacher> teachers);

	TeacherDTO convertToDTO(Teacher teacher);
	
}
