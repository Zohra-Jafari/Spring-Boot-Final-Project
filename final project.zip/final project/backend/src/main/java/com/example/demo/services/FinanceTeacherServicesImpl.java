package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.DTO.FinanceTeacherDTO;
import com.example.demo.model.FinanceTeacher;
import com.example.demo.repository.FinanceTeacherRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceTeacherServicesImpl implements FinanceTeacherServices {
    
    @Autowired
    private FinanceTeacherRepository financeTeacherRepository;

    @Autowired
    private ModelMapper modelMapper;
    @Override
    public FinanceTeacher addFinance(FinanceTeacher finance) {
        return financeTeacherRepository.save(finance);
    }

    @Override
    public List<FinanceTeacher> getAllFinances() {
        return financeTeacherRepository.findAll();
    }

    @Override
    public FinanceTeacher getFinanceById(Integer id) {
        return financeTeacherRepository.getOne(id);
    }

    @Override
    public void deleteFinanceById(Integer id) {
        financeTeacherRepository.deleteById(id);
        
    }

    @Override
    public List<FinanceTeacherDTO> convertToDTO(List<FinanceTeacher> finances) {
        List<FinanceTeacherDTO> financeTeacherDTOList = new ArrayList<>();
        for(FinanceTeacher fTeacher: finances){
            FinanceTeacherDTO financeTeacherDTO = modelMapper.map(fTeacher, FinanceTeacherDTO.class);
            financeTeacherDTOList.add(financeTeacherDTO);
        }
        return financeTeacherDTOList;
    }

    @Override
    public FinanceTeacherDTO convertToDTO(FinanceTeacher financeTeacher) {
        FinanceTeacherDTO financeTeacherDTO = modelMapper.map(financeTeacher, FinanceTeacherDTO.class);
        return financeTeacherDTO;
    }
}
