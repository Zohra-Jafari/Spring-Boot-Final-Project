package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.DTO.FinanceStudentDTO;
import com.example.demo.model.FinanceStudent;
import com.example.demo.repository.FinanceRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FinanceServicesImpl implements FinanceServices {

    @Autowired
    private FinanceRepository financeRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public FinanceStudent addFinance(FinanceStudent finance) {
        return financeRepository.save(finance);
    } 

    @Override
    public List<FinanceStudent> getAllFinances() {
        return financeRepository.findAll();
    }

    @Override
    public FinanceStudent getFinanceById(Integer id) {
        return financeRepository.getOne(id);
    }

    @Override
    public void deleteFinanceById(Integer id) {
        financeRepository.deleteById(id);

    }

    @Override
    public List<FinanceStudentDTO> convertToDTO(List<FinanceStudent> finances) {
        List<FinanceStudentDTO> financeStudentDTOList = new ArrayList<>();
        for(FinanceStudent fStudent: finances){
            FinanceStudentDTO financeStudentDTO = modelMapper.map(fStudent, FinanceStudentDTO.class);
            financeStudentDTOList.add(financeStudentDTO);
       }
        return financeStudentDTOList;
    }

    @Override
    public FinanceStudentDTO convertToDTO(FinanceStudent financeStudent) {
        FinanceStudentDTO financeStudentDTO = modelMapper.map(financeStudent, FinanceStudentDTO.class);
        return financeStudentDTO;
    }

}
