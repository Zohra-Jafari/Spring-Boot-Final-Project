package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.ClassesDTO;
import com.example.demo.model.Classes;
import com.example.demo.services.ClassServices;





/**
 * ApplicationController
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ClassController {

    @Autowired
    private ClassServices classService;      //polemorphism

    //_______________________ student part
    @GetMapping(path = "/class/all")
    public ResponseEntity<List<ClassesDTO>> getClasses(){

        List<Classes> classes = classService.getAllClasses();

        List<ClassesDTO> classesDTOList = classService.convertToDTO(classes);

        return new ResponseEntity<>(classesDTOList, HttpStatus.OK);


    }
    

    @PostMapping("/class/add")
    public ResponseEntity<ClassesDTO> addClass(@RequestBody Classes classe){
       Classes SavedClass = classService.addClass(classe);
       ClassesDTO classesDTO = classService.convertToDTO(SavedClass);
        return new ResponseEntity<>(classesDTO, HttpStatus.CREATED);
    }



    @GetMapping("/class/{id}")
    public ResponseEntity<Classes> getClass(@PathVariable("id") Integer id){
        Classes classe = classService.getClassById(id);
        return new ResponseEntity<>(classe, HttpStatus.OK);
    }



    @PutMapping("/class/update")
    public ResponseEntity<Classes> updateClass(@RequestBody Classes classe){
        Classes SavedClass = classService.addClass(classe);
        return new ResponseEntity<>(SavedClass, HttpStatus.OK);
    }



    @DeleteMapping("/class/{id}/delete")
    public ResponseEntity<String> deleteClass(@PathVariable("id") Integer id){
        classService.deleteClassById(id);
        return new ResponseEntity<>("class " + id + " deleted", HttpStatus.OK);
    }


}