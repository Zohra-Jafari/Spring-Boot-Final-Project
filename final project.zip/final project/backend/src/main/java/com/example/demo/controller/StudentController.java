package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.StudentDTO;
import com.example.demo.model.Student;
import com.example.demo.services.StudentServices;


/**
 * ApplicationController
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class StudentController {

    @Autowired
    private StudentServices studentService;      //polemorphism

    //_______________________ student part
    @GetMapping(path = "/student/all")
    public ResponseEntity<List<StudentDTO>> getStudents(){

        List<Student> students = studentService.getAllStudents();

        List<StudentDTO> studentDTOList = studentService.convertToDTO(students);

        return new ResponseEntity<>(studentDTOList, HttpStatus.OK);


    }
    

    @PostMapping("/student/add")
    public ResponseEntity<StudentDTO> addStudent(@RequestBody Student student){
       Student SavedStudent = studentService.addStudent(student);
       StudentDTO studentDTO = studentService.convertToDTO(SavedStudent);
        return new ResponseEntity<>(studentDTO, HttpStatus.CREATED);
    }



    @GetMapping("/student/{id}")
    public ResponseEntity<Student> getStudent(@PathVariable("id") Integer id){
        Student student = studentService.getStudentById(id);
        return new ResponseEntity<>(student, HttpStatus.OK);
    }



    @PutMapping("/student/update")
    public ResponseEntity<Student> updateEntity(@RequestBody Student student){
        Student SavedStudent = studentService.addStudent(student);
        return new ResponseEntity<>(SavedStudent, HttpStatus.OK);
    }



    @DeleteMapping("/student/{id}/delete")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") Integer id){
        studentService.deleteStudentById(id);
        return new ResponseEntity<>("Student " + id + " deleted", HttpStatus.OK);
    }


}