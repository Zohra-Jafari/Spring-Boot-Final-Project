package com.example.demo.services;

import java.util.List;

import com.example.demo.DTO.FinanceStudentDTO;
import com.example.demo.model.FinanceStudent;





public interface FinanceServices {
    
    FinanceStudent addFinance(FinanceStudent finance);

	List<FinanceStudent> getAllFinances();

	FinanceStudent getFinanceById(Integer id);

	void deleteFinanceById(Integer id);

    List<FinanceStudentDTO> convertToDTO(List<FinanceStudent> finances);

	FinanceStudentDTO convertToDTO(FinanceStudent financeStudent);

	
}
