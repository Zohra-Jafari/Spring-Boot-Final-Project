package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.FinanceStudentDTO;
import com.example.demo.model.FinanceStudent;
import com.example.demo.services.FinanceServices;



/**
 * ApplicationController
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class FinanceController {

    @Autowired
    private FinanceServices financeService;      //polemorphism

    //_______________________ student part
    @GetMapping(path = "/finance/all")
    public ResponseEntity<List<FinanceStudentDTO>> getFinances(){

        List<FinanceStudent> finances = financeService.getAllFinances();

        List<FinanceStudentDTO> financeStudentDTOList = financeService.convertToDTO(finances);

        return new ResponseEntity<>(financeStudentDTOList, HttpStatus.OK);


    }
    

    @PostMapping("/finance/add")
    public ResponseEntity<FinanceStudentDTO> addFinance(@RequestBody FinanceStudent finance){
       FinanceStudent SavedFinance = financeService.addFinance(finance);
       FinanceStudentDTO financeStudentDTO = financeService.convertToDTO(SavedFinance);
        return new ResponseEntity<>(financeStudentDTO, HttpStatus.CREATED);
    }



    @GetMapping("/finance/{id}")
    public ResponseEntity<FinanceStudent> getFinance(@PathVariable("id") Integer id){
        FinanceStudent finance = financeService.getFinanceById(id);
        return new ResponseEntity<>(finance, HttpStatus.OK);
    }



    @PutMapping("/finance/update")
    public ResponseEntity<FinanceStudent> updateFinance(@RequestBody FinanceStudent finance){
        FinanceStudent SavedFinance = financeService.addFinance(finance);
        return new ResponseEntity<>(SavedFinance, HttpStatus.OK);
    }



    @DeleteMapping("/finance/{id}/delete")
    public ResponseEntity<String> deleteFinance(@PathVariable("id") Integer id){
        financeService.deleteFinanceById(id);
        return new ResponseEntity<>("finance " + id + " deleted", HttpStatus.OK);
    }


}