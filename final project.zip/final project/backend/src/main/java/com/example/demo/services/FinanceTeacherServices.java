package com.example.demo.services;

import java.util.List;

import com.example.demo.DTO.FinanceTeacherDTO;
import com.example.demo.model.FinanceTeacher;

public interface FinanceTeacherServices {

    FinanceTeacher addFinance(FinanceTeacher finance);

    List<FinanceTeacher> getAllFinances();

    FinanceTeacher getFinanceById(Integer id);

    void deleteFinanceById(Integer id);

    List<FinanceTeacherDTO> convertToDTO(List<FinanceTeacher> finances);
    
    FinanceTeacherDTO convertToDTO(FinanceTeacher financeTeacher);
}
