package com.example.demo.DTO;

public class FinanceTeacherDTO {

    private Integer _id;
    private String firstname;
    private String lastname;
    private String month;
    private Number money;

    private Integer teacher_Id;

    public FinanceTeacherDTO() {
    }


    public Integer getTeacher_Id() {
        return teacher_Id;
    }


    public void setTeacher_Id(Integer teacher_Id) {
        this.teacher_Id = teacher_Id;
    }


    public FinanceTeacherDTO(Integer _id, String firstname, String lastname, String month, Number money) {
        this._id = _id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.month = month;
        this.money = money;
    }



    
    public Integer get_id() {
        return _id;
    }
    public void set_id(Integer _id) {
        this._id = _id;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getMonth() {
        return month;
    }
    public void setMonth(String month) {
        this.month = month;
    }
    public Number getMoney() {
        return money;
    }
    public void setMoney(Number money) {
        this.money = money;
    }
    







    
}
