package com.example.demo.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "students")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Student {

    private Integer _id;
    private String firstname;
    private String lastname;
    private String fathername;
    private String gender;
    private Number idnumber;
    private String classname;
    private String time;
    private Number year;


    private Classes classSc;
    private FinanceStudent FStudent;
    private Set<Teacher> teachers;


    //default constractor
    public Student() {
    }

    //many to many(teacher and student)
    @ManyToMany
    public Set<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(Set<Teacher> teachers) {
        this.teachers = teachers;
    }

    //many to one(student and Fstudent)
    @OneToOne
    public FinanceStudent getFStudent() {
        return FStudent;
    }

    public void setFStudent(FinanceStudent fStudent) {
        this.FStudent = fStudent;
    }


    //one to many(class and student)
    @ManyToOne
    public Classes getClassSc() {
        return classSc;
    }
    public void setClassSc(Classes classSc) {
        this.classSc = classSc;
    }



    //overload constractor
    public Student(Integer _id, String firstname, String lastname,String fathername, String gender,Number idnumber, String classname, String time, Number year) {
        this._id = _id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.fathername = fathername;
        this.gender = gender;
        this.idnumber = idnumber;
        this.classname = classname;
        this.time = time;
        this.year = year;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Number getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(Number idnumber) {
        this.idnumber = idnumber;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Number getYear() {
        return year;
    }

    public void setYear(Number year) {
        this.year = year;
    }


    
    
}
