package com.example.demo.controller;

import java.util.List;

import com.example.demo.DTO.FinanceTeacherDTO;
import com.example.demo.model.FinanceTeacher;
import com.example.demo.services.FinanceTeacherServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class FinanceTeacherController {
    

    @Autowired
    private FinanceTeacherServices financeTeacherServices;


    //_______________________ teacher part
    @GetMapping(path = "/TeacherFinance/all")
    public ResponseEntity<List<FinanceTeacherDTO>> getFinances(){
        List<FinanceTeacher> finances = financeTeacherServices.getAllFinances();
        List<FinanceTeacherDTO> financeTeacherDTOList = financeTeacherServices.convertToDTO(finances);
        return new ResponseEntity<>(financeTeacherDTOList, HttpStatus.OK);
    }

    @PostMapping("/TeacherFinance/add")
    public ResponseEntity<FinanceTeacherDTO> addFinance(@RequestBody FinanceTeacher finance){
        FinanceTeacher SavedFinance = financeTeacherServices.addFinance(finance);
        FinanceTeacherDTO financeTeacherDTO = financeTeacherServices.convertToDTO(SavedFinance);
        return new ResponseEntity<>(financeTeacherDTO, HttpStatus.CREATED);
    }

    @GetMapping("/TeacherFinance/{id}")
    public ResponseEntity<FinanceTeacher> getFinance(@PathVariable("id") Integer id){
        FinanceTeacher finance = financeTeacherServices.getFinanceById(id);
        return new ResponseEntity<>(finance, HttpStatus.OK);
    }

    @PutMapping("/TeacherFinance/update")
    public ResponseEntity<FinanceTeacher> updateFinance(@RequestBody FinanceTeacher finance){
        FinanceTeacher SavedFinance = financeTeacherServices.addFinance(finance);
        return new ResponseEntity<>(SavedFinance, HttpStatus.OK);
    }

    @DeleteMapping("/TeacherFinance/{id}/delete")
    public ResponseEntity<String> deleteFinance(@PathVariable("id") Integer id){
        financeTeacherServices.deleteFinanceById(id);
        return new ResponseEntity<>("finance " + id + " deleted", HttpStatus.OK);
    }
}
