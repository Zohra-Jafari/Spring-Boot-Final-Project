package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.TeacherDTO;
import com.example.demo.model.Teacher;
import com.example.demo.services.TeacherServices;




/**
 * ApplicationController
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TeacherController {

    @Autowired
    private TeacherServices teacherService;      //polemorphism

    //_______________________ student part
    @GetMapping(path = "/teacher/all")
    public ResponseEntity<List<TeacherDTO>> getTeachers(){

        List<Teacher> teachers = teacherService.getAllTeachers();

        List<TeacherDTO> teacherDTOList = teacherService.convertToDTO(teachers);

        return new ResponseEntity<>(teacherDTOList, HttpStatus.OK);


    }
    

    @PostMapping("/teacher/add")
    public ResponseEntity<TeacherDTO> addTeacher(@RequestBody Teacher teacher){
       Teacher SavedTeacher = teacherService.addTeacher(teacher);
       TeacherDTO teacherDTO = teacherService.convertToDTO(SavedTeacher);
        return new ResponseEntity<>(teacherDTO, HttpStatus.CREATED);
    }



    @GetMapping("/teacher/{id}")
    public ResponseEntity<Teacher> getTeacher(@PathVariable("id") Integer id){
        Teacher teacher = teacherService.getTeacherById(id);
        return new ResponseEntity<>(teacher, HttpStatus.OK);
    }



    @PutMapping("/teacher/update")
    public ResponseEntity<Teacher> updateTeacher(@RequestBody Teacher teacher){
        Teacher SavedTeacher = teacherService.addTeacher(teacher);
        return new ResponseEntity<>(SavedTeacher, HttpStatus.OK);
    }



    @DeleteMapping("/teacher/{id}/delete")
    public ResponseEntity<String> deleteTeacher(@PathVariable("id") Integer id){
        teacherService.deleteTeacherById(id);
        return new ResponseEntity<>("finance " + id + " deleted", HttpStatus.OK);
    }


}