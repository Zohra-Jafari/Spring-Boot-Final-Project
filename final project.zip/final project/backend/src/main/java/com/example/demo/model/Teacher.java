package com.example.demo.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "teachers")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Teacher {

    private Integer _id;
	private String firstname;
	private String lastname;
    private String gender;
    private Number salary;
    private String time;

	private Set<Classes> classes;
	private Set<Student> students;
	private FinanceTeacher financeTeacher;

    //default constractor
    public Teacher() {
    }

	//one to one(teacher and financeTeacher)
	@OneToOne()
	public FinanceTeacher getFinanceTeacher() {
		return financeTeacher;
	}


	public void setFinanceTeacher(FinanceTeacher financeTeacher) {
		this.financeTeacher = financeTeacher;
	}


	//many to many(teacher and student)
	@ManyToMany(mappedBy = "teachers", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}


	//one to many(teacher and class)
	@OneToMany(mappedBy = "teacher", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public Set<Classes> getClasses() {
		return classes;
	}

	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}


	
	//overload constractor
    public Teacher(Integer _id, String firstname,String lastname, String gender, Number salary, String time) {
        this._id = _id;
		this.firstname = firstname;
        this.lastname = lastname;
        this.gender = gender;
        this.salary = salary;
        this.time = time;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer get_id() {
		return _id;
	}

	public void set_id(Integer _id) {
		this._id = _id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Number getSalary() {
		return salary;
	}

	public void setSalary(Number salary) {
		this.salary = salary;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}



    
    
}
