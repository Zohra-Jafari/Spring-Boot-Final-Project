package com.example.demo.services;

// import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
// import java.util.stream.Collector;
// import java.util.stream.Collectors;

import com.example.demo.DTO.TeacherDTO;
import com.example.demo.model.Teacher;
import com.example.demo.repository.TeacherRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServicesImpl implements TeacherServices {

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Teacher addTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    } 

    @Override
    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    @Override
    public Teacher getTeacherById(Integer id) {
        return teacherRepository.getOne(id);
    }

    @Override
    public void deleteTeacherById(Integer id) {
        teacherRepository.deleteById(id);

    }

    @Override
    public List<TeacherDTO> convertToDTO(List<Teacher> teachers) {
        List<TeacherDTO> teacherDTOList = new ArrayList<>();
        for(Teacher teacher: teachers){
            TeacherDTO teacherDTO = modelMapper.map(teacher, TeacherDTO.class);
            // teacherDTO.setStudents_Ids(teacher.getStudents().stream().map(student -> student.get_id()).collect(Collectors.toSet());
            teacherDTOList.add(teacherDTO);
        }
        return teacherDTOList;
    }

    @Override
    public TeacherDTO convertToDTO(Teacher teacher) {
        TeacherDTO teacherDTO = modelMapper.map(teacher, TeacherDTO.class);
        return teacherDTO;
    }

}
