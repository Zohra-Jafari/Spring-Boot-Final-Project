package com.example.demo.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "classes")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Classes {

    private Integer _id;
	private String classname;

	private Set<Student> students;
	private Teacher teacher;


    //default constractor
    public Classes() {
    }

	//one to many(teacher and class)
	@ManyToOne
	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	//one to many (class and student)
	@OneToMany(mappedBy = "classSc", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    public Set<Student> getStudents() {
		return students;
	}


	public void setStudents(Set<Student> students) {
		this.students = students;
	}


	//overload constractor
    public Classes(Integer _id, String classname) {
        this._id = _id;
		this.classname = classname;
    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer get_id() {
		return _id;
	}

	public void set_id(Integer _id) {
		this._id = _id;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}


    
    
}
