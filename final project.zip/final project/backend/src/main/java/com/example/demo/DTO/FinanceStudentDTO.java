package com.example.demo.DTO;

public class FinanceStudentDTO {

    private Integer _id;
    private String firstname;
    private Number idnumber;
    private String month;
    private Number money;

    private Integer student_Id;

    public FinanceStudentDTO() {
    }


    public Integer getStudent_Id() {
        return student_Id;
    }


    public void setStudent_Id(Integer student_Id) {
        this.student_Id = student_Id;
    }


    public FinanceStudentDTO(Integer _id, String firstname, Number idnumber, String month, Number money) {
        this._id = _id;
        this.firstname = firstname;
        this.idnumber = idnumber;
        this.month = month;
        this.money = money;
    }



    public Integer get_id() {
        return _id;
    }
    public void set_id(Integer _id) {
        this._id = _id;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public Number getIdnumber() {
        return idnumber;
    }
    public void setIdnumber(Number idnumber) {
        this.idnumber = idnumber;
    }
    public String getMonth() {
        return month;
    }
    public void setMonth(String month) {
        this.month = month;
    }
    public Number getMoney() {
        return money;
    }
    public void setMoney(Number money) {
        this.money = money;
    }
    








    
}
