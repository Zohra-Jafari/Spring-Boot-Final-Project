package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.DTO.StudentDTO;
import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServicesImpl implements StudentServices {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Student addStudent(Student student) {
        return studentRepository.save(student);
    } 

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student getStudentById(Integer id) {
        return studentRepository.getOne(id);
    }

    @Override
    public void deleteStudentById(Integer id) {
        studentRepository.deleteById(id);

    }

    @Override
    public List<StudentDTO> convertToDTO(List<Student> students) {
        List<StudentDTO> studentDTOList = new ArrayList<>();
        for(Student student: students){
            StudentDTO studentDTO = modelMapper.map(student, StudentDTO.class);
            studentDTO.setTeachers_Ids(student.getTeachers().stream().map(teacher -> teacher.get_id()).collect(Collectors.toSet()));
            // StudentDTO studentDTO = new StudentDTO();
            // studentDTO.set_id(student.get_id());
            // studentDTO.setFirstname(student.getFirstname());
            // studentDTO.setLastname(student.getLastname());
            // studentDTO.setFathername(student.getFathername());
            // studentDTO.setGender(student.getGender());
            // studentDTO.setIdnumber(student.getIdnumber());
            // studentDTO.setClassname(student.getClassname());
            // studentDTO.setTime(student.getTime());
            // studentDTO.setYear(student.getYear());
            studentDTOList.add(studentDTO);
        }
        
        return studentDTOList;
    }

    @Override
    public StudentDTO convertToDTO(Student student) {
        StudentDTO studentDTO = modelMapper.map(student, StudentDTO.class);
        return studentDTO;
    }

}
