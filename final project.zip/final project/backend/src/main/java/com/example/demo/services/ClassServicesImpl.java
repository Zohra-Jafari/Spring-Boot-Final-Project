package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.DTO.ClassesDTO;
import com.example.demo.model.Classes;
import com.example.demo.repository.ClassRepository;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClassServicesImpl implements ClassServices {

    @Autowired
    private ClassRepository classRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Classes addClass(Classes classe) {
        return classRepository.save(classe);
    } 

    @Override
    public List<Classes> getAllClasses() {
        return classRepository.findAll();
    }

    @Override
    public Classes getClassById(Integer id) {
        return classRepository.getOne(id);
    }

    @Override
    public void deleteClassById(Integer id) {
        classRepository.deleteById(id);

    }

    @Override
    public List<ClassesDTO> convertToDTO(List<Classes> classes) {
        List<ClassesDTO> classesDTOList = new ArrayList<>();
        for(Classes classd: classes){
            ClassesDTO classesDTO = modelMapper.map(classd, ClassesDTO.class);
            classesDTOList.add(classesDTO);
        }
        return classesDTOList;
    }

    @Override
    public ClassesDTO convertToDTO(Classes classes) {
        ClassesDTO classesDTO = modelMapper.map(classes, ClassesDTO.class);
        return classesDTO;
    }

}
