package com.example.demo.DTO;

import java.util.Set;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class TeacherDTO {
    
    private Integer _id;
	private String firstname;
	private String lastname;
    private String gender;
    private Number salary;
    private String time;

    private Integer financeTeacher_Id;
    private Set<Integer> classes_Ids;
    private Set<Integer> students_Ids;

    
    public TeacherDTO() {
    }


    public Set<Integer> getClasses_Ids() {
        return classes_Ids;
    }


    public void setClasses_Ids(Set<Integer> classes_Ids) {
        this.classes_Ids = classes_Ids;
    }


    public Set<Integer> getStudents_Ids() {
        return students_Ids;
    }


    public void setStudents_Ids(Set<Integer> students_Ids) {
        this.students_Ids = students_Ids;
    }


    public Integer getFinanceTeacher_Id() {
        return financeTeacher_Id;
    }


    public void setFinanceTeacher_Id(Integer financeTeacher_Id) {
        this.financeTeacher_Id = financeTeacher_Id;
    }


    public TeacherDTO(Integer _id, String firstname, String lastname, String gender, Number salary, String time) {
        this._id = _id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.gender = gender;
        this.salary = salary;
        this.time = time;

    }

    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }


    public void set_id(Integer _id) {
        this._id = _id;
    }


    public String getFirstname() {
        return firstname;
    }


    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }


    public String getLastname() {
        return lastname;
    }


    public void setLastname(String lastname) {
        this.lastname = lastname;
    }


    public String getGender() {
        return gender;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }


    public Number getSalary() {
        return salary;
    }


    public void setSalary(Number salary) {
        this.salary = salary;
    }


    public String getTime() {
        return time;
    }


    public void setTime(String time) {
        this.time = time;
    }


    









}
