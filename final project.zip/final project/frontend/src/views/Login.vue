<template>
    <div class="student-form">
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field v-model="username" label="User Name"></v-text-field>
              </v-col>
            <v-col cols="12" sm="3">
                <v-text-field type="password" label="Password" v-model="password"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-btn color="info" @click="login">Login</v-btn>
            </v-col>
        </v-row>
    </div>
</template>



<script lang="ts">
export default {
    // props:["studentId"],

    //data
    data() {
        return{
            username: null,
            password: null,
            // classname: null,
            // time: null,
            // year: null,
            // items: ["Male", "Female"],
            // times: ["Morning", "Afternoon"],
            // Classes:[],
            // a:[]
        }
    },
 
    // async mounted(){
        // const response = await EmployeeServices.getAllClass();
        // this.a = response.data;
        // console.log(response.data);
        // this.a.forEach(element => {
            // this.Classes.push(element.classname);
        // });
    // },


    //methods
    methods: {
       async login() {
            const user = {
                username: this.username,
                password: this.password
                // classname: this.classname,
                // time: this.time,
                // year: this.year
            };

            await this.$store.dispatch("login", user);
            this.$router.push("/addstudent");

            // console.log(student);
            // const savedStudent = await EmployeeServices.addStudent(student);
            // console.log(savedStudent);
            // this.resetForm();
            // this.$store.dispatch("updateSnackbar", {
                // snackbar: true,
                // text: "Student Saved Successfully",
                // timeout: 2000
            // });
        },
        // resetForm(){
            // this.firstname = null;
            // this.lastname = null;
            // this.fathername = null,
            // this.gender = null;
            // this.idnumber = null;
            // this.classname = null;
            // this.time = null;
            // this.year = null;

        // },
        // async updateStudent(){
            // const student = {
                // _id: this.studentId,
                // firstname: this.firstname,
                // lastname: this.lastname,
                // fathername: this.fathername,
                // gender: this.gender,
                // idnumber: this.idnumber,
                // classname: this.classname,
                // time: this.time,
                // year: this.year
        // }
    //    const response = await EmployeeServices.updateStudent(student);
    //    const updateingStudent = response.data;
            // this.$store.dispatch("updateSnackbar", {
                // snackbar: true,
                // text: "Student Updated Successfully",
                // timeout: 2000
            // });
        // setTimeout(() => {
            // this.$router.push("/student");
        // },2000)

    //    console.log(updateingStudent);
    // },
    // reset () {
            // this.firstname = null;
            // this.lastname = null;
            // this.fathername = null;
            // this.gender = null;
            // this.idnumber = null;
            // this.classname = null;
            // this.time = null;
            // this.year = null; 
    //   },
        // ClickPlus(){
            // this.$router.push("/addclass");
        // }
    },

    //created
    // async created(){
        // if(this.studentId){
        // const response = await EmployeeServices.getById(this.studentId);
        // const student = response.data;
        // this.firstname = student.firstname;
        // this.lastname= student.lastname;
        // this.fathername = student.fathername;
        // this.gender = student.gender;
        // this.idnumber = student.idnumber;
        // this.classname = student.classname;
        // this.time = student.time;
        // this.year= student.year;
        // }
    // },
}
    
</script>

<style scoped>
.student-form{
    margin: auto;
}
</style>