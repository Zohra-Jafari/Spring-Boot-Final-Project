<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
            <h2>Edit Finance</h2>
        </v-col>
    </v-row>
    <FinanceForm :financeId="FinanceId" />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import FinanceForm from "../../components/FinanceForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    components:{
        FinanceForm: FinanceForm,
        MySnackbar: MySnackbar
    },
    data(){
        return{
            FinanceId : this.$route.params.id
        }
    }
}
</script>

<style>

</style>