<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
            <h2>Edit Teacher Finance</h2>
        </v-col>
    </v-row>
    <FinanceForm :financeId="FinanceId" />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import FinanceForm from "../../components/TeacherFinanceForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    components:{
        FinanceForm: FinanceForm,
        MySnackbar: MySnackbar
    },
    data(){
        return{
            FinanceId : this.$route.params.id
        }
    }
}
</script>

<style>

</style>