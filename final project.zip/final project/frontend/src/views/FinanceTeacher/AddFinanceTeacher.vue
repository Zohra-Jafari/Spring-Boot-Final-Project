<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
          <h2>Teacher Finance Registration</h2>
        </v-col>
    </v-row>
    <FinanceForm />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import FinanceForm from "../../components/TeacherFinanceForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    data(){
      return{
        
      }
    },
    components:{
        FinanceForm: FinanceForm,
        MySnackbar: MySnackbar
    }
}
</script>

<style>

</style>