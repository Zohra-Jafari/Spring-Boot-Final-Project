<template>
  <div>
    <v-simple-table>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">First Name</th>
          <th class="text-left">Last Name</th>
          <th class="text-left">Month</th>
          <th class="text-left">Salary</th>
          <th class="text-left">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="finance in finances" :key="finance._id">
          <td>{{ finance.firstname }}</td>
          <td>{{ finance.lastname }}</td>
          <td>{{ finance.month }}</td>
          <td>{{ finance.money }}</td>
          <td>
            <v-btn small color="warning" class="mr-2" :to="`/financeTeacher/${finance._id}/edit`">Edit</v-btn>
            <v-btn small color="error" @click="deleteFinance(finance._id)">Delete</v-btn>
          </td>
        </tr>
      </tbody>
      <div>
        <v-snackbar color="info" right v-model="snackbar">
          {{ text }}
            <template v-slot:action="{ attrs }">
              <v-btn color="dark" text  v-bind="attrs"  @click="snackbar = false">Close</v-btn>
            </template>
        </v-snackbar>
      </div>
    </template>
  </v-simple-table>
  </div>
</template>

<script>
import EmployeeServices from '../../api/EmployeeServices';
export default {
    data (){
        return{
            finances: [],
            snackbar: false,
            text: "Finance Deleted"
        }
    },
    async mounted(){
        const response = await EmployeeServices.getAllFinanceTeacher();
        this.finances = response.data;
        console.log(this.finances);
    },
    methods:{
      async deleteFinance(financeId){
        const conf = confirm("Do you really want delete this finance ?");
        if(conf){
        const response = await EmployeeServices.FinanceTeacherDeleteById(financeId);
        console.log(response.data);
        this.snackbar = true;
        this.finances = this.finances.filter(finance => {
          return finance._id !== financeId;
        })
        }
      }
    }
}
</script>

<style>
th, td {
  border: 1px solid gray;
}
</style>