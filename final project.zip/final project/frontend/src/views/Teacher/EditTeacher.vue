<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
            <h2>Edit Teacher</h2>
        </v-col>
    </v-row>
    <TeacherForm :teacherId="TeacherId" />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import TeacherForm from "../../components/TeacherForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    components:{
        TeacherForm: TeacherForm,
        MySnackbar: MySnackbar
    },
    data(){
        return{
            TeacherId : this.$route.params.id
        }
    }
}
</script>

<style>

</style>