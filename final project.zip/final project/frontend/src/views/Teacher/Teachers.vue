<template>
  <div>
    <v-simple-table>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">First Name</th>
          <th class="text-left">Last Name</th>
          <th class="text-left">Gender</th>
          <th class="text-left">Salary</th>
          <th class="text-left">Time</th> 
          <th class="text-left">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="teacher in teachers" :key="teacher._id">
          <td>{{ teacher.firstname }}</td>
          <td>{{ teacher.lastname }}</td>
          <td>{{ teacher.gender }}</td>
          <td>{{ teacher.salary }}</td>
          <td>{{ teacher.time }}</td>
          <td>
            <v-btn small color="warning" class="mr-2" :to="`/teacher/${teacher._id}/edit`">Edit</v-btn>
            <v-btn small color="error" @click="deleteTeacher(teacher._id)">Delete</v-btn>
            <v-btn small color="primary" :to="`/addfinanceTeacher/${teacher._id}`">Finance</v-btn>
        
          </td>
        </tr>
      </tbody>
      <div>
        <v-snackbar color="info" right v-model="snackbar">
          {{ text }}
            <template v-slot:action="{ attrs }">
              <v-btn color="dark" text  v-bind="attrs"  @click="snackbar = false">Close</v-btn>
            </template>
        </v-snackbar>
      </div>
    </template>
  </v-simple-table>
  </div>
</template>

<script>
import EmployeeServices from '../../api/EmployeeServices';
export default {
  props:["teacherId"],

    data (){
        return{
            teachers: [],
            snackbar: false,
            text: "Teacher Deleted"
        }
    },
    async mounted(){
        const response = await EmployeeServices.getAllTeacher();
        this.teachers = response.data;
        console.log("ssssssssss");
    },
    methods:{
      async deleteTeacher(teacherId){
        const conf = confirm("Do you really want delete this teacher ?");
        if(conf){
        const response = await EmployeeServices.TeacherDeleteById(teacherId);
        console.log(response.data);
        this.snackbar = true;
        this.teachers = this.teachers.filter(teacher => {
          return teacher._id !== teacherId;
        })
        }
      }
    }
}
</script>

<style>
th, td {
  border: 1px solid gray;
}
</style>