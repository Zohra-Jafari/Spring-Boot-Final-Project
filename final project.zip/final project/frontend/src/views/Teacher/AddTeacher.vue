<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
          <h2>Teacher Registration</h2>
        </v-col>
    </v-row>
    <TeacherForm />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import TeacherForm from "../../components/TeacherForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    data(){
      return{
         
      }
    },
    components:{
        TeacherForm: TeacherForm,
        MySnackbar: MySnackbar
    }
}
</script>

<style>

</style>