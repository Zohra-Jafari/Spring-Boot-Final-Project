<template>
    <div class="home">
        <div class="head">
        <h1>Home Page</h1>
        <p class="para1">Video provides a powerful way to help you prove your point. <br>When you click Online Video, you can paste in the embed<br> code for the video you want to add. You can also type a <br> keyword to search online for the video that best fits your<br> document.
            To make your document look professionally,<br>produced, Word provides header, footer, cover page, and<br> text box designs that complement each other. For example,<br> you can add a matching cover page, header, and sidebar.<br> Click Insert and then choose the elements you want from<br> the different galleries.
        </p>
        <p class="para1 mb-20">Video provides a powerful way to help you prove your point. <br>When you click Online Video, you can paste in the embed<br> code for the video you want to add. You can also type a <br> keyword to search online for the video that best fits your<br> document.
        </p>
        </div>
        <div class="home-img">
            <img src="../assets/homeImg.png" alt="School" width="600" height="600">
        </div>
    </div>
</template>

<script>


export default {
    name: "Home",
    data: () => ({})
}
</script>

<style scoped>
.head{
    float: left;
    margin-top: 6%;
    margin-right:3% ;
}
.home-img{
    margin-top: 5%;
    
}
</style>