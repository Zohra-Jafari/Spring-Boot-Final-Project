<template>
  <div>
        <h1 class="head-About">ABOUT US</h1><hr>
        <div class="IMG">
        <img src="../assets/aboutImg.png" alt="School" width="600" height="600">
        </div>
        <p class="para1">Video provides a powerful way to help you prove your point. <br>When you click Online Video, you can paste in the embed<br> code for the video you want to add. You can also type a <br> keyword to search online for the video that best fits your<br> document.
            To make your document look professionally,<br>produced, Word provides header, footer, cover page, and<br> text box designs that complement each other. For example,<br> you can add a matching cover page, header, and sidebar.<br> Click Insert and then choose the elements you want from<br> the different galleries.
        </p>
        <p class="para1">Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type  keyword to search online for the video that best fits your document.</p>
        
  </div>
</template>

<script>
export default {

}
</script>

<style>
.IMG{
  float: left;
}
.head-About{
  text-align: center;
  margin-top: 3%;
}
.para1{
  margin-top: 5%;
}
</style>