<template>
  <div>
    <v-row>
        <v-col cols="12" sm="3" class="dark--text">
          <h2>Student Registration</h2>
        </v-col>
    </v-row>
    <StudentForm />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import StudentForm from "../../components/StudentForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    data(){
      return{

      }
    },
    components:{
        StudentForm: StudentForm,
        MySnackbar: MySnackbar
    }
}
</script>

<style>

</style>