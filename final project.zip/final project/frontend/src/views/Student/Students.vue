<template>
  <div>
    <v-simple-table>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">First Name</th>
          <th class="text-left">Last Name</th>
          <th class="text-left">Father Name</th>
          <th class="text-left">Gender</th>
          <th class="text-left">ID Number</th>
          <th class="text-left">Class</th>
          <th class="text-left">Time</th>
          <th class="text-left">Year</th>  
          <th class="text-left">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="student in students" :key="student._id">
          <td>{{ student.firstname }}</td>
          <td>{{ student.lastname }}</td>
          <td>{{ student.fathername }}</td>
          <td>{{ student.gender }}</td>
          <td>{{ student.idnumber }}</td>
          <td>{{ student.classname }}</td>
          <td>{{ student.time }}</td>
          <td>{{ student.year }}</td>
          <td>
            <v-btn small color="warning" class="mr-2" :to="`/student/${student._id}/edit`">Edit</v-btn>
            <v-btn small color="error" @click="deleteStudent(student._id)" class="mr-2">Delete</v-btn>
            <v-btn small color="primary" :to="`/addfinance/${student._id}`">Finance</v-btn>
          </td>
        </tr>
      </tbody>
      <div>
        <v-snackbar color="info" right v-model="snackbar">
          {{ text }}
            <template v-slot:action="{ attrs }">
              <v-btn color="dark" text  v-bind="attrs"  @click="snackbar = false">Close</v-btn>
            </template>
        </v-snackbar>
      </div>
    </template>
  </v-simple-table>
  </div>
</template>

<script>
import EmployeeServices from '../../api/EmployeeServices';
export default {
    props:["studentId"],

    data (){
        return{
            students: [],
            snackbar: false,
            text: "Student Deleted"
        }
    },
    async mounted(){
        const response = await EmployeeServices.getAllStudent();
        this.students = response.data;
        console.log("ssssssssss");
    },
    methods:{
      async deleteStudent(studentId){
        const conf = confirm("Do you really want delete this student ?");
        if(conf){
        const response = await EmployeeServices.deleteById(studentId);
        console.log(response.data);
        this.snackbar = true;
        this.students = this.students.filter(student => {
          return student._id !== studentId;
        })
        }
      },
    },
 
}
</script>

<style>
th, td {
  border: 1px solid gray;
}
</style>