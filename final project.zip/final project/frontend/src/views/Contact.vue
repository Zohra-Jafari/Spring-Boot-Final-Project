<template>
    <div class="about">
        <h1 class="head-About">CONTACT</h1><hr>
        <p class="para1">We'd <v-icon>mdi-heart-outline</v-icon> to help!</p>
        <p class="para2">We like to create with fun, open-minded people. Feel free to say hello!</p>
          <div class="part1">
          <v-row>
            <v-col cols="12" sm="9">
                <v-text-field label="Your Name"></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" sm="9">
                <v-text-field label="Email"></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" sm="9">
              <v-textarea counter label="Massage" :rules="rules" :value="value"></v-textarea>
            </v-col>
          </v-row>
          <v-btn color="info">Send</v-btn>
          </div>
          <div class="part2">
            <v-icon class="telegram" large>mdi-google-maps</v-icon>
              <p id="param">CTI Web Design</p><p class="subParam"> HERAT, AF</p><br>
            <v-icon class="telegram" large>mdi-phone</v-icon>
              <p id="param">(93)790-030277</p><br><br>
            <v-icon class="telegram" large>mdi-email</v-icon>
              <p id="param">zohrajafari@gmail.com</p><br><br><hr class="hr"><br>
            <div class="end-part">
              <v-icon class="telegram1" large>mdi-twitter</v-icon>
              <v-icon class="telegram1" large>mdi-facebook</v-icon>
              <v-icon class="telegram1" large>mdi-telegram</v-icon>
            </div>
            <p id="end-param">Cti Web Design In Herat</p>
          </div>
    </div>
</template>

<style scoped>
.head-About{
  text-align: center;
}
.telegram{
  margin-right: 13%;
  font-size: 120%;
}
.telegram1{
  font-size: 120%;
  margin-right: 5%;
}
.end-part{
  margin-left: 18%;
}
#end-param{
  margin-left: 15%;
}
#param{
  display: inline-block;
  text-align: center;
}
.subParam{
  margin-left: 25%;
  margin-top: -3%;
}
.about-address{
  margin-top: 3%;
}
.about{
  margin-top: 2%;
}
.para1{
  text-align: center;
  font-size: 150%;
}
.para2{
  text-align: center;
}
.part1{
  width: 50%;
  float: left;
}
.part2{
  width: 30%;
  float: right;
  margin-top: 5%;
  margin-right: 15%;
}
.hr{
  width: 70%;
}
</style>