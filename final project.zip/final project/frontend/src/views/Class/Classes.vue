<template>
  <div>
    <v-simple-table>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">Class Name</th>
          <th class="text-left">Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="clas in classes" :key="clas._id">
          <td>{{ clas.classname }}</td>
          <td>
            <v-btn small color="warning" class="mr-2" :to="`/class/${clas._id}/edit`">Edit</v-btn>
            <v-btn small color="error" @click="deleteClass(clas._id)">Delete</v-btn>
          </td>
        </tr>
      </tbody>
      <div>
        <v-snackbar color="info" right v-model="snackbar">
          {{ text }}
            <template v-slot:action="{ attrs }">
              <v-btn color="dark" text  v-bind="attrs"  @click="snackbar = false">Close</v-btn>
            </template>
        </v-snackbar>
      </div>
    </template>
  </v-simple-table>
  </div>
</template>

<script>
import EmployeeServices from '../../api/EmployeeServices';
export default {
    data (){
        return{
            classes: [],
            snackbar: false,
            text: "Class Deleted"
        }
    },
    async mounted(){
        const response = await EmployeeServices.getAllClass();
        this.classes = response.data;
        console.log("ssssssssss");
    },
    methods:{
      async deleteClass(classId){
        const conf = confirm("Do you really want delete this class ?");
        if(conf){
        const response = await EmployeeServices.ClassDeleteById(classId);
        console.log(response.data);
        this.snackbar = true;
        this.classes = this.classes.filter(classs => {
          return classs._id !== classId;
        })
        }
      }
    }
}
</script>

<style>
th, td {
  border: 1px solid gray;
}
</style>