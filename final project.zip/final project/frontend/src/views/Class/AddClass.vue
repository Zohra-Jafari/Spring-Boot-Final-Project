<template>
  <div>
    <v-row>
        <v-col cols="12" sm="6" class="dark--text">
          <h2>Class Registration</h2>
        </v-col>
    </v-row>
    <ClassForm />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import ClassForm from "../../components/ClassForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    data(){
      return{

      }
    },
    components:{
        ClassForm: ClassForm,
        MySnackbar: MySnackbar
    }
}
</script>

<style>

</style>