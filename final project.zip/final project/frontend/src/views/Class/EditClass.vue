<template>
  <div>
    <v-row>
        <v-col cols="12" sm="6" class="dark--text">
            <h2>Edit Class</h2>
        </v-col>
    </v-row>
    <ClassForm :classId="ClassId" />
    <MySnackbar></MySnackbar>
  </div>
</template>

<script>
import ClassForm from "../../components/ClassForm";
import MySnackbar from "../../components/MySnackbar";
export default {
    components:{
        ClassForm: ClassForm,
        MySnackbar: MySnackbar
    },
    data(){
        return{
            ClassId : this.$route.params.id
        }
    }
}
</script>

<style>

</style>