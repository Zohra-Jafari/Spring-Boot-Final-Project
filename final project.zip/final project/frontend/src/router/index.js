import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Contact from "../views/Contact.vue";


import AddStudent from "../views/Student/AddStudent";
import Student from "../views/Student/Students";
import StudentEdit from "../views/Student/EditStudent";

import TeacherEdit from "../views/Teacher/EditTeacher";
import AddTeacher from "../views/Teacher/AddTeacher";
import Teachers from "../views/Teacher/Teachers";

import AddFinance from "../views/Finance/AddFinance";
import FinanceEdit from "../views/Finance/EditFinance";
import Finances from "../views/Finance/Finances";

import AddFinanceTeacher from "../views/FinanceTeacher/AddFinanceTeacher";
import TeacherFinances from "../views/FinanceTeacher/FinanceTeacher";
import TeacherFinanceEdit from "../views/FinanceTeacher/EditFinanceTeacher";

import AddClass from "../views/Class/AddClass";
import Classes from "../views/Class/Classes";
import ClassEdit from "../views/Class/EditClass";

import Signup from "../views/Signup";
import Login from "../views/Login";






Vue.use(VueRouter);

const routes = [{
        path: "/",
        name: "Home",
        component: Home,
        meta: { authentication: true }
    },
    {
        path: "/about",
        name: "About",
        component: () =>
            import ( /* webpackChinkName: "about" */ "../views/About.vue")
    },
    {
        path: "/addstudent",
        name: "Add Student",
        component: AddStudent,
    },
    {
        path: "/student",
        name: "Student All",
        component: Student
    },
    {
        path: "/student/:id/edit",
        name: "Student Edit",
        component: StudentEdit
    },
    {
        path: "/addteacher",
        name: "Add Teacher",
        component: AddTeacher
    },
    {
        path: "/teacher",
        name: "Teacher All",
        component: Teachers
    },
    {
        path: "/teacher/:id/edit",
        name: "Edit Teacher",
        component: TeacherEdit

    },
    {
        path: "/addfinance/:id",
        name: "Add Finance",
        component: AddFinance
    },
    {
        path: "/finance",
        name: "Finance All",
        component: Finances
    },
    {
        path: "/finance/:id/edit",
        name: "Edit Finance",
        component: FinanceEdit
    },
    {
        path: "/addfinanceTeacher/:id",
        name: "Add Teacher Finance",
        component: AddFinanceTeacher
    },
    {
        path: "/financeTeacher",
        name: "Teacher Finance All",
        component: TeacherFinances
    },
    {
        path: "/financeTeacher/:id/edit",
        name: "Edit Teacher Finance",
        component: TeacherFinanceEdit
    },
    {
        path: "/addclass",
        name: "Add Class",
        component: AddClass
    },
    {
        path: "/class",
        name: "Class All",
        component: Classes

    },
    {
        path: "/class/:id/edit",
        name: "Edit Class",
        component: ClassEdit
    },
    {
        path: "/contact",
        name: "Contact Us",
        component: Contact
    },
    {
        path: "/user/register",
        name: "Signup",
        component: Signup
    },
    {
        path: "/login",
        name: "Login",
        component: Login
    }

];

const router = new VueRouter({
    mode: "history",
    base: process.env.BASE_URL,
    routes
});

router.beforeEach((to, from, next) => {
    const loggedIn = localStorage.getItem("user");
    if (to.matched.some(item => item.meta.authentication) && !loggedIn) {
        next("/");
    } else {
        next();
    }
});

export default router;