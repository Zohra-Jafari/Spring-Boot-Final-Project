import axiosClient from "./axiosClient";

export default {

    //____________________________ Student Part

    addStudent(student) {
        return axiosClient.post("/student/add", student);
    },

    getAllStudent() {
        return axiosClient.get("/student/all");
    },

    deleteById(studentId) {
        return axiosClient.delete(`/student/${studentId}/delete`);
    },

    getById(studentId) {
        return axiosClient.get(`/student/${studentId}`);
    },

    updateStudent(student) {
        return axiosClient.put("/student/update", student);
    },

    //_____________________________ Teacher Part
    addTeacher(teacher) {
        return axiosClient.post("/teacher/add", teacher);
    },

    getAllTeacher() {
        return axiosClient.get("/teacher/all");
    },

    TeacherDeleteById(teacherId) {
        return axiosClient.delete(`/teacher/${teacherId}/delete`);
    },

    getByIdTeacher(teacherId) {
        return axiosClient.get(`/teacher/${teacherId}`);
    },

    updateTeacher(teacher) {
        return axiosClient.put("/teacher/update", teacher);
    },


    //_____________________________Student Finance Part
    addFinance(finance) {
        return axiosClient.post("/finance/add", finance);
    },

    getAllFinance() {
        return axiosClient.get("/finance/all");
    },

    FinanceDeleteById(financeId) {
        return axiosClient.delete(`/finance/${financeId}/delete`);
    },

    getByIdFinance(financeId) {
        return axiosClient.get(`/finance/${financeId}`);
    },

    updateFinance(finance) {
        return axiosClient.put("/finance/update", finance);
    },

    //_____________________________Teacher Finance Part
    addFinanceTeacher(finance) {
        return axiosClient.post("/TeacherFinance/add", finance);
    },

    getAllFinanceTeacher() {
        return axiosClient.get("/TeacherFinance/all");
    },

    FinanceTeacherDeleteById(financeId) {
        return axiosClient.delete(`/TeacherFinance/${financeId}/delete`);
    },

    getByIdFinanceTeacher(financeId) {
        return axiosClient.get(`/TeacherFinance/${financeId}`);
    },

    updateFinanceTeacher(finance) {
        return axiosClient.put("/Teacherinance/update", finance);
    },


    //____________________________ Class Part
    addClass(classe) {
        return axiosClient.post("/class/add", classe);
    },

    updateClass(classe) {
        return axiosClient.put("/class/update", classe);
    },

    getByIdClass(classId) {
        return axiosClient.get(`/class/${classId}`);
    },

    getAllClass() {
        return axiosClient.get("/class/all");
    },

    ClassDeleteById(classId) {
        return axiosClient.delete(`/class/${classId}/delete`);
    },
}