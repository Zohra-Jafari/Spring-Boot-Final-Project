<template>
    <div class="student-form">
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field v-model="firstname" label="First Name"></v-text-field>
              </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="Last Name" v-model="lastname"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-select :items="items" label="Gender" v-model="gender"></v-select>
            </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="Salary" v-model="salary"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-select :items="times" label="Time" v-model="time"></v-select>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-btn v-if="teacherId" color="info" @click="updateTeacher">Update</v-btn>
                <v-btn v-else color="info" @click="savaTeacher">Sava</v-btn>
                <v-btn color="error" class="ml-2" @click="reset">Reset Form</v-btn>
            </v-col>
        </v-row>
        </div>    
</template>



<script lang="ts">
import EmployeeServices from "../api/EmployeeServices";
export default {
    props:["teacherId"],

    //data
    data() {
        return{
            firstname: null,
            lastname: null,
            fathername: null,
            gender: null,
            salary: null,
            time: null,
            items: ["Male", "Female"],
            times: ["Morning", "Afternoon"],
        }
    },


    //methods
    methods: {
       async savaTeacher() {
            const teacher = {
                firstname: this.firstname,
                lastname: this.lastname,
                gender: this.gender,
                salary: this.salary,
                time: this.time,
            };
            console.log(teacher);
            const savedTeacher = await EmployeeServices.addTeacher(teacher);
            console.log(savedTeacher);
            this.resetForm();
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Teacher Saved Successfully",
                timeout: 1000
            })
        },
        resetForm(){
            this.firstname = null;
            this.lastname = null;
            this.gender = null;
            this.salary = null;
            this.time = null;
        },
        async updateTeacher(){
            const teacher = {
                _id: this.teacherId,
                firstname: this.firstname,
                lastname: this.lastname,
                gender: this.gender,
                salary: this.salary,
                time: this.time,
        }
       const response = await EmployeeServices.updateTeacher(teacher);
       const updateingTeacher = response.data;
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Teacher Updated Successfully",
                timeout: 1000
            });
        setTimeout(() => {
            this.$router.push("/teacher");
        },2000)
       console.log(updateingTeacher);
    },
    reset () {
            this.firstname = null;
            this.lastname = null;
            this.gender = null;
            this.salary = null;
            this.time = null;
      }
    },

    //created
    async created(){
        if(this.teacherId){
        const response = await EmployeeServices.getByIdTeacher(this.teacherId);
        const teacher = response.data;
        this.firstname = teacher.firstname;
        this.lastname= teacher.lastname;
        this.gender = teacher.gender;
        this.salary = teacher.salary;
        this.time = teacher.time;
        }
    }
}
    
</script>

<style scoped>
.student-form{
    margin: auto;
}
</style>