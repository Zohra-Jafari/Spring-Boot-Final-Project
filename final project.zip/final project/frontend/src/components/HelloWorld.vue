<template>
    <v-container>
        <!-- {{ hello }} -->
        {{ msg }}
    </v-container>
</template>


<script>
export default {
    name: "HelloWorld",
    props: ["msg"],


    data: () => ({
        hello: "Hello World"
    })
};
</script>