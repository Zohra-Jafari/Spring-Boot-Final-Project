<template>
    <div class="student-form">
        <v-row>
            <v-col cols="12" sm="6">
                <v-text-field v-model="classname" label="Class Name"></v-text-field>
              </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-btn v-if="classId" color="info" @click="updateClass">Update</v-btn>
                <v-btn v-else color="info" @click="savaClass">Sava</v-btn>
                <v-btn color="error" class="ml-2" @click="reset">Reset Form</v-btn>
            </v-col>
        </v-row>
    </div>
</template>



<script lang="ts">
import EmployeeServices from "../api/EmployeeServices";
export default {
    props:["classId"],

    //data
    data() {
        return{
            classname: null,
        }
    },


    //methods
    methods: {
       async savaClass() {
            const classes = {
                classname: this.classname,
            };
            console.log(classes);
            const savedClass = await EmployeeServices.addClass(classes);
            console.log(savedClass);
            this.resetForm();
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Class Saved Successfully",
                timeout: 1000
            })
        },
        resetForm(){
            this.classname = null;
        },
        async updateClass(){
            const classes = {
                _id: this.classId,
                classname: this.classname,
        }
       const response = await EmployeeServices.updateClass(classes);
       const updateingClass = response.data;
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Class Updated Successfully",
                timeout: 1000
            })
        setTimeout(() => {
            this.$router.push("/class");
        },2000)

       console.log(updateingClass);
    },
    reset () {
            this.classname = null;
      }
    },

    //created
    async created(){
        if(this.classId){
        const response = await EmployeeServices.getByIdClass(this.classId);
        const classes = response.data;
        this.classname = classes.classname;
        }
    }
}
    
</script>

<style scoped>

</style>