<template>
    <div class="text-center ma-2">
        <v-snackbar color="info" right v-model="snackbar" :timeout="timeout">
            {{ text }}
            <template v-slot:action="{ attrs }">
                <v-btn color="dark" text  v-bind="attrs"  @click="snackbar = false">Close</v-btn>
            </template>
        </v-snackbar>
    </div>
</template>

<script>
import { mapState } from "vuex";
export default {
    // data 
    data(){
        return{
        snackbar: false
        }
    },

    //computed
    computed: mapState(["text", "timeout"]),
    
    //created
    created(){
        this.$store.subscribe(mutation => {
            if(mutation.type == "SET_SNACKBAR"){
                this.snackbar = true
            }
        })
    }

}
</script>


<style>

</style>