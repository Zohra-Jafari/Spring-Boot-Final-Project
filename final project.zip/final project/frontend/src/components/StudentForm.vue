<template>
    <div class="student-form">
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field v-model="firstname" label="First Name"></v-text-field>
              </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="Last Name" v-model="lastname"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field label="Father Name" v-model="fathername"></v-text-field>
            </v-col>
            <v-col cols="12" sm="3">
                <v-select :items="items" label="Gender" v-model="gender"></v-select>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field label="ID Number" v-model="idnumber"></v-text-field>
            </v-col>
            <v-col cols="12" sm="3">
                <v-select :items="Classes" label="Class" v-model="classname"></v-select>
            </v-col>
            <v-col cols="12" sm="3" class="mt-3">
                <v-list-item-icon>
                <v-btn x-small @click="ClickPlus">
                 <v-icon>mdi-plus-box</v-icon>
                </v-btn>
                </v-list-item-icon>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-select :items="times" label="Time" v-model="time"></v-select>
            </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="Year" v-model="year"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-btn v-if="studentId" color="info" @click="updateStudent">Update</v-btn>
                <v-btn v-else color="info" @click="savaStudent">Sava</v-btn>
                <v-btn color="error" class="ml-2" @click="reset">Reset Form</v-btn>
            </v-col>
        </v-row>
    </div>
</template>



<script lang="ts">
import EmployeeServices from "../api/EmployeeServices";
export default {
    props:["studentId"],

    //data
    data() {
        return{
            firstname: null,
            lastname: null,
            fathername: null,
            gender: null,
            idnumber: null,
            classname: null,
            time: null,
            year: null,
            items: ["Male", "Female"],
            times: ["Morning", "Afternoon"],
            Classes:[],
            a:[]
        }
    },
 
    async mounted(){
        const response = await EmployeeServices.getAllClass();
        this.a = response.data;
        console.log(response.data);
        this.a.forEach(element => {
            this.Classes.push(element.classname);
        });
    },


    //methods
    methods: {
       async savaStudent() {
            const student = {
                firstname: this.firstname,
                lastname: this.lastname,
                fathername: this.fathername,
                gender: this.gender,
                idnumber: this.idnumber,
                classname: this.classname,
                time: this.time,
                year: this.year
            };
            console.log(student);
            const savedStudent = await EmployeeServices.addStudent(student);
            console.log(savedStudent);
            this.resetForm();
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Student Saved Successfully",
                timeout: 2000
            });
        },
        resetForm(){
            this.firstname = null;
            this.lastname = null;
            this.fathername = null,
            this.gender = null;
            this.idnumber = null;
            this.classname = null;
            this.time = null;
            this.year = null;

        },
        async updateStudent(){
            const student = {
                _id: this.studentId,
                firstname: this.firstname,
                lastname: this.lastname,
                fathername: this.fathername,
                gender: this.gender,
                idnumber: this.idnumber,
                classname: this.classname,
                time: this.time,
                year: this.year
        }
       const response = await EmployeeServices.updateStudent(student);
       const updateingStudent = response.data;
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Student Updated Successfully",
                timeout: 2000
            });
        setTimeout(() => {
            this.$router.push("/student");
        },2000)

       console.log(updateingStudent);
    },
    reset () {
            this.firstname = null;
            this.lastname = null;
            this.fathername = null;
            this.gender = null;
            this.idnumber = null;
            this.classname = null;
            this.time = null;
            this.year = null; 
      },
        ClickPlus(){
            this.$router.push("/addclass");
        }
    },

    //created
    async created(){
        if(this.studentId){
        const response = await EmployeeServices.getById(this.studentId);
        const student = response.data;
        this.firstname = student.firstname;
        this.lastname= student.lastname;
        this.fathername = student.fathername;
        this.gender = student.gender;
        this.idnumber = student.idnumber;
        this.classname = student.classname;
        this.time = student.time;
        this.year= student.year;
        }
    },
}
    
</script>

<style scoped>
.student-form{
    margin: auto;
}
</style>