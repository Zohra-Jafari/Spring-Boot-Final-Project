<template>
    <div class="student-form">
        <v-row>
            <v-col cols="12" sm="3">
                <v-text-field v-model="firstname" label="First Name"></v-text-field>
            </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="ID Number" v-model="idnumber"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-select :items="items" label="Month" v-model="month"></v-select>
            </v-col>
            <v-col cols="12" sm="3">
                <v-text-field label="Money" v-model="money"></v-text-field>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3">
                <v-btn v-if="financeId" color="info" @click="updateFinance">Update</v-btn>
                <v-btn v-else color="info" @click="savaFinance">Sava</v-btn>
                <v-btn color="error" class="ml-2" @click="reset">Reset Form</v-btn>
            </v-col>
        </v-row>
    </div>
</template>



<script lang="ts">
import EmployeeServices from "../api/EmployeeServices";
export default {
    props:["financeId"],

    //data
    data() {
        return{
            firstname: null,
            idnumber: null,
            month: null,
            money: null,
            items: ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth"],
        }
    },
    

    //computed
    computed:{
        studentId(){
            return this.$route.params.id
        }

    },

    //methods
    methods: {
       async savaFinance() {
            const finance = {
                firstname: this.firstname,
                idnumber: this.idnumber,
                month: this.month,
                money: this.money,
            };
            console.log(finance);
            const savedFinance = await EmployeeServices.addFinance(finance);
            console.log(savedFinance);
            this.resetForm();
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Finance Saved Successfully",
                timeout: 1000
            })
        },
        resetForm(){
            this.firstname = null;
            this.idnumber= null;
            this.month = null;
            this.money = null;
        },
        async updateFinance(){
            const finance = {
                _id: this.financeId,
                firstname: this.firstname,
                idnumber: this.idnumber,
                month: this.month,
                money: this.money,
        }
       const response = await EmployeeServices.updateFinance(finance);
       const updateingFinance = response.data;
            this.$store.dispatch("updateSnackbar", {
                snackbar: true,
                text: "Finance Updated Successfully",
                timeout: 1000
            })
        setTimeout(() => {
            this.$router.push("/finance");
        },2000)
       console.log(updateingFinance);
    },
    reset () {
            this.firstname = null;
            this.idnumber = null;
            this.month = null;
            this.money = null;
      }
    },

    // created
    async created(){
        if(this.studentId){
        const response = await EmployeeServices.getById(this.studentId);
        const student = response.data;
        this.firstname = student.firstname;
        this.idnumber = student.idnumber;
        console.log(this.studentId);
        }

        if(this.financeId){
        const response = await EmployeeServices.getByIdFinance(this.financeId);
        const finance = response.data;
        this.firstname = finance.firstname;
        this.idnumber = finance.idnumber;
        this.month = finance.month;
        this.money = finance.money;
        }

    }
}
    
</script>

<style scoped>

</style>