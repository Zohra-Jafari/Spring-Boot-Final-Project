import Vue from 'vue';
import Vuex from 'vuex';
import UserService from "../api/UserServices";

Vue.use(Vuex);

export default new Vuex.Store({

    state: {
        // snackbar: false,
        text: "",
        timeout: 2000,
        user: null
    },
    mutations: {
        SET_SNACKBAR: (state, payload) => {
            // state.snackbar = payload.snackbar,
            state.text = payload.text,
                state.timeout = payload.timeout
        },

        SET_USER: (state, userData) => {
            state.user = userData;
            localStorage.getItem("user", JSON.stringify(userData));
            UserService.addAuthorizationHeader(userData.token);
        },
        CLEAR_USER: (() => {
            // state.user = null;
            // UserService.removeAthorizationHeader();
            location.reload();
            localStorage.removeItem("user");
        })
    },
    actions: {
        updateSnackbar({ commit }, payload) {
            commit("SET_SNACKBAR", payload);
        },

        async signup({ commit }, user) {

            const response = await UserService.register(user);
            commit("SET_USER", response.data);
        },

        async login({ commit }, user) {
            const response = await UserService.login(user);
            commit("SET_USER", response.data);

        },

        logout({ commit }) {
            commit("CLEAR_USER");
        }
    },

    getters: {
        loggedIn(state) {
            return !!state.user;
        }
    },

    modules: {}
});