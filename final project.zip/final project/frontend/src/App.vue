<template class="temp">
    <v-app class="app">
      <!-- start header div  -->
      <div class="header">
        <img src="./assets/header.png" alt="School" width="300" height="60" class="header-img">
      </div>
      <!-- end header div -->

      <!-- strat main div -->
      <div class="Main">

        <!-- Strat Sidbar div -->
        <div class="sidbar">
          <v-card>
            <v-navigation-drawer v-model="drawer" :mini-variant.sync="mini" permanent height="836">
              <v-list-item class="px-2">
                <v-list-item-icon>
                  <v-icon>mdi-format-align-right</v-icon>
                </v-list-item-icon>
                <v-list-item-title>Navegation</v-list-item-title>
                <v-btn icon @click.stop="mini = !mini">
                  <v-icon>mdi-chevron-left</v-icon>
                </v-btn>
              </v-list-item>
              <v-divider></v-divider>

              <v-list>
                <v-list-item>
                  <v-list-item-icon>
                   <v-icon>mdi-home</v-icon>
                  </v-list-item-icon>
                  <v-list-item-title><router-link to="/" class="black-text" id="route-link">Home</router-link></v-list-item-title>
                </v-list-item>

                <v-list-group>
                  <template v-slot:activator>
                    <v-list-item-icon>
                      <v-icon>mdi-account-multiple</v-icon>
                    </v-list-item-icon>
                    <v-list-item-title>Registration</v-list-item-title>
                  </template>

                  <v-list-item>
                    <v-list-item-title> <router-link to="/addstudent" class="black--text" id="route-link">Student Registration</router-link></v-list-item-title>
                  </v-list-item>

                  <v-list-item>
                    <v-list-item-title><router-link to="/addteacher" class="black--text" id="route-link">Teacher Registration</router-link></v-list-item-title>
                  </v-list-item>
                </v-list-group>

                <v-list-item>
                  <v-list-item-icon>
                    <v-icon>mdi-home-city</v-icon>
                  </v-list-item-icon>
                  <v-list-item-title><router-link to="/addclass" class="black--text" id="route-link">Class Registration</router-link></v-list-item-title>
                </v-list-item>

                <v-list-group>
                  <template v-slot:activator>
                    <v-list-item-icon>
                      <v-icon>mdi-file-table-box-multiple</v-icon>
                    </v-list-item-icon>
                    <v-list-item-title>Tables</v-list-item-title>
                  </template>

                  <v-list-item>
                    <v-list-item-title><router-link to="/student" class="black--text" id="route-link">Students Table</router-link></v-list-item-title>
                  </v-list-item>

                  <v-list-item>
                    <v-list-item-title><router-link to="/class" class="black--text" id="route-link">Class Table</router-link></v-list-item-title>
                  </v-list-item>

                  <v-list-item>
                    <v-list-item-title><router-link to="/teacher" class="black--text" id="route-link">Teacher Table</router-link></v-list-item-title>
                  </v-list-item>
                </v-list-group>
        
                <v-list-group>
                  <template v-slot:activator>
                    <v-list-item-icon>
                      <v-icon>mdi-equalizer</v-icon>
                    </v-list-item-icon>
                    <v-list-item-title>Finance</v-list-item-title>
                  </template>

                  <v-list-item>
                    <v-list-item-title><router-link to="/finance" class="black--text" id="route-link">Student Finance Table</router-link></v-list-item-title>
                  </v-list-item>
                  <v-list-item>
                    <v-list-item-title><router-link to="/financeTeacher" class="black--text" id="route-link">Teacher Finance Table</router-link></v-list-item-title>
                  </v-list-item>
                </v-list-group>
                <span v-if="!loggedIn">
                  <v-list-item>
                    <v-list-item-title><router-link to="/user/register" class="black--text" id="route-link">Sign Up</router-link></v-list-item-title>
                  </v-list-item>
                  <v-list-item>
                    <v-list-item-title><router-link to="/login" class="black--text" id="route-link">Login</router-link></v-list-item-title>
                  </v-list-item>
                </span>
                <span v-else>
                  <v-btn color="primary" @click="logout">Log Out</v-btn>
                </span>
                
                </v-list>
              </v-navigation-drawer>
            </v-card>
          </div>
          <!-- end sidbar div  -->
          
           <v-container>
            <router-view />
           </v-container>
          
          </div>
          <!-- end main div  -->

          <!-- strat footer div  -->
          <div class="footer">
            <p>2020, School System
            <router-link to="/contact" class="black-text" id="a1">Contact us</router-link>
            <router-link to="/about" class="black-text" id="a2"> About us</router-link>
            </p>
          </div>
          <!-- end footer div  -->
    </v-app>
</template>


<script>
export default {
  name: "App",
  data(){
   return{
     drawer: true,
     mini: true,
   }
  },

  methods:{
    logout(){
      this.$store.dispatch("logout");
    }
  },

  computed:{
    loggedIn(){
     return this.$store.getters.loggedIn;
    }
  }
};
</script>

<style scoped>
.temp{
  width: 100%;
}
 .header{
   background-color: #24478f;
   width: 100%;
   height: 8%;
 }
 .header-img{
   margin-left: 3%;
   margin-top: 4px;
 }
 .header p{
   display: inline-block;
   margin-bottom: 1% ;
   
 }
 .Main{
   background-color: #ebf0fa;
   width: 112%;
   height: 84%;
 }
 .sidbar{
   float: left;
   margin-top: 2px;
   margin-right: 3%;
 }
 .footer{
   background-color:  #ebf0fa;
   width:100%;
   height: 8%;
   clear: both;
   margin-top:3px;
 }
 .footer p{
   margin-top: 1.3%;
   margin-left: 2%;
 }
 #a1{
  margin-left: 75%;
  text-decoration: none;
 }
 #a2{
  margin-left: 2%;
  text-decoration: none;
 }
 #route-link{
    text-decoration: none;
 }
</style>
